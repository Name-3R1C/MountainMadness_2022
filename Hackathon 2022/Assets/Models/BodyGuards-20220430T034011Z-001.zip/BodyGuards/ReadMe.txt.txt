Bodyguards 1.0

Package contains three unique characters, fourth is added as a bonus. These are skined, game ready characters. You can use them as agents, bodyguards, policemans, mafiosos etc. Each character have 2k diffuse, normal, specular,Ao maps connected to PBS material. It is perfect for any type of game and for prototyping games. Polycount for characters is: 7970, 8508, 9043 and 7792 triangles.

-Release 1.2
Characters are now skined to a new rig. The same rig that user "Kubold" is using in his animations packages. These characters are now fully compatible with Kubold's animations, without any retargeting and adjusting guns.
